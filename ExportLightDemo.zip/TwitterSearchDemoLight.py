# -*- coding: utf-8 -*-
#!/usr/bin/env python

from tkinter import *
from tkinter import ttk

import json
import subprocess
import io

import os
import sys
import webbrowser as web


force_cache = ''

root = Tk(className="Enter text then press Show Cloud then enter keywords and press Collect Tweets")
samplesFrame = Frame(root)
samplesFrame.pack(side=TOP)

textFrame = Frame(root)
textFrame.pack()

kwFrame = Frame(root)
kwFrame.pack()

bottomframe = Frame(root)
bottomframe.pack(fill=BOTH)

textPad = Text(textFrame, width=70, height=8, padx=5, pady=5, wrap=WORD, font=("Helvetica",24))
kwPad = Entry(kwFrame, width=50, font=("Helvetica",32))
   
# comment out after testing:
#def set_values(filename):
#    global force_cache
#    file = open(filename+'.txt', 'r', encoding='utf-8')
#    textPad.delete('1.0',END)
#    textPad.insert(INSERT,file.read())
#    file = open(filename+'_kw.txt', 'r', encoding='utf-8')
#    kwPad.delete(0, END)
#    kwPad.insert(INSERT, file.read())
#    force_cache = 'forceCache'
#    return

def execute(command):
    process = subprocess.Popen(command, shell=True, bufsize = 1, universal_newlines=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    while True:
        nextline = process.stdout.readline()
        if nextline == '' and process.poll() is not None:
            break
        sys.stdout.write(nextline)
        sys.stdout.flush()
    return


#def show_bad_tweets():
#    web.open_new_tab('BadTwitterOutput.html'); # for MacOS, use the full name: file:/xxx/yyy/Bad*.html
#    return

#Disabled at first (TODO disable when changing the text input!)
#D = Button(bottomframe, state=DISABLED, text ="show least relevant tweets", command =lambda: show_bad_tweets())

def collect_tweet():
    global force_cache
    filename = "demoInput.json"
    with open(filename, "w") as outfile:
        labels =  kwPad.get().split()
        json.dump({'result': {'labels': labels, 'text': textPad.get("1.0",END) }}, outfile, indent=4)
# If "java" is not in the PATH, put the full path name below (e.g. "/etc/bin/java -jar TwitterSearch.jar"):
    batcmd="java -jar TwitterSearch.jar "+filename+" "+force_cache
    execute(batcmd)
    #D['state'] = 'normal'
    if sys.platform == 'win32': # For windows it works fine to just give the relative path
        web.open_new_tab('TwitterOutput.html');
    else: # for other OS, use the full name: file:/xxx/yyy/*.html
        web.open_new_tab('file:'+os.getcwd+os.sep+'TwitterOutput.html')
    return

def clear_fields():
    global force_cache
    textPad.delete('1.0',END)
    kwPad.delete(0, END)
    #D['state'] = 'disabled'
    force_cache = ''
    return

def save_fields():
    basefilename = kwPad.get().replace(' ','_').replace('\n','')
    filename = basefilename+".txt"
    with open(filename, "w", encoding='utf-8') as outfile:
        outfile.write(textPad.get("1.0",END))
    filename = basefilename+"_kw.txt"
    with open(filename, "w") as outfile:
        outfile.write(kwPad.get())
    return


A99 = Button(textFrame, text ="Clear", command =lambda: clear_fields())
A98 = Button(kwFrame, text ="Save", command =lambda: save_fields())
C = Button(bottomframe, text ="Collect Tweets and show most relevant ones", command =lambda: collect_tweet())

A99.pack(pady=(10,0), padx=10, side=RIGHT)
textPad.pack(pady=10, padx=15, fill=BOTH)
C.pack(pady=10, padx=10, side=LEFT)
#D.pack(pady=10, padx=10, side=RIGHT)
kwPad.pack(pady=10, padx=15, side=LEFT)
#A98.pack(pady=(10,0), padx=10, side=RIGHT)

#TESTING:
#set_values('morning_trump_tweet_merryl_streep')

root.mainloop()

